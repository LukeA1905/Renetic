//
//  DisplayCodeTView.swift
//  ReneticFinal
//
//  Created by Luke Austin on 14/04/2023.
//

import UIKit
import Firebase
import FirebaseFirestore

class DisplayCodeTView: UIViewController {
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    
    
}

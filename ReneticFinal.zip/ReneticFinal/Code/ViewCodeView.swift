//
//  ViewCodeView.swift
//  ReneticFinal
//
//  Created by Luke Austin on 10/04/2023.
//

import UIKit
import Firebase
import FirebaseFirestore

class ViewCodeView: UIViewController {

    
    @IBOutlet weak var myLabel: UILabel!
    var db: Firestore!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        }
    

  

}

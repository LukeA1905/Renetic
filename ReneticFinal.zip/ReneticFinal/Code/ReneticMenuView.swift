//
//  ReneticMenuView.swift
//  ReneticFinal
//
//  Created by Luke Austin on 01/04/2023.
//

import UIKit

class ReneticMenuView: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func createAccountBtn(_ sender: Any) {
        // This button will take the user to the create Account Page
        
    }
    
    
    
    @IBAction func logInBtn(_ sender: Any) {
        
        // This button will take the user to the login page
    }
}

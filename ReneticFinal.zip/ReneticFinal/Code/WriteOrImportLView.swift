//
//  WriteOrImportLView.swift
//  ReneticFinal
//
//  Created by Luke Austin on 11/04/2023.
//

import UIKit

class WriteOrImportLView: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

   
    @IBAction func importFileBtn(_ sender: Any) {
    }
    
    
}

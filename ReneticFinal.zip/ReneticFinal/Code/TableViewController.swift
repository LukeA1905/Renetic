//
//  TableViewController.swift
//  ReneticFinal
//
//  Created by Luke Austin on 16/04/2023.
//

import UIKit
import Firebase

class TableViewController: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Register the custom table view cell class
    }
}
    

